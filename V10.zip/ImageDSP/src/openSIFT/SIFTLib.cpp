#include "ezsift.h"
#include <qglobal.h>
#include <QPoint>
#include "SIFTlib.h"

using namespace std;

/*******************************************************************************************************************************/
/* Find SIFT keypoints */
/*******************************************************************************************************************************/
SiftKeypointList calculateSIFT(const uchar Y_buff[], int width, int height)
{
	ezsift::Image<unsigned char>* image = new ezsift::Image<unsigned char>(width, height);
	SiftKeypointList kpList;

	for (int i = 0; i < width*height; i++)
	{
		image->data[i] = Y_buff[i];
	}

	bool bExtractDescriptor = true;
	

	// Double the original image as the first octive.
	ezsift::double_original_image(true);

	// Perform SIFT computation on CPU.
	ezsift::sift_cpu(*image, kpList, bExtractDescriptor);

    delete image;
	return kpList;
}
