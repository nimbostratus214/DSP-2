
#ifndef _FEATURE_DETECTION_H_
#define _FEATURE_DETECTION_H_

#include <QtGlobal>
#include "SIFTTypes.h"

/*******************************************************************************************************************************/
/* Return list od SIFT keypoints for a given RGB image */
/*******************************************************************************************************************************/
SiftKeypointList GetSIFTFeatures(const uchar input[], int xSize, int ySize);

#endif //  _FEATURE_DETECTION_H_
