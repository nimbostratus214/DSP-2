#ifndef SIFTLIB_H_
#define SIFTLIB_H_

#include <qglobal.h>
#include <QPoint.h>
#include <list>
#include "SIFTTypes.h"

/*******************************************************************************************************************************/
/* Find SIFT keypoints */
/*******************************************************************************************************************************/
SiftKeypointList calculateSIFT(const uchar Y_buff[], int width, int height);


#endif