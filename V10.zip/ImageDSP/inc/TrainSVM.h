#ifndef _TRAIN_SVM_H_
#define _TRAIN_SVM_H_

#include "DataBase.h"

//Size of feature vector for SVM (BoW histogram size)
const int histogramSize = 10;

bool trainSVM(const ImgDataBase& dataBase, bool createNewBoWModel, std::string BOWModelFileName, std::string SVMModelFileName);

bool crossValidateKFold(const ImgDataBase& dataBase, int K, bool createNewBoWModel, std::string BOWModelFileName);

#endif // _TRAIN_SVM_H_
