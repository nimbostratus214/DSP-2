#pragma once
#include <vector>
#include "DataBase.h"
#include <string>

typedef struct
{
	std::vector<std::vector<double>> model;
	int numOfClusters;
	int featureVectorSize;
} BagOfWordsModel;


BagOfWordsModel createBoWModel(const ImgDataBase& dataBase, int K);

std::vector<double> getBoWDescripton(uchar input[], int xSize, int ySize, const BagOfWordsModel& model);

bool dumpBoWModel(const BagOfWordsModel& model, std::string filename);

bool loadBoWModel(BagOfWordsModel& model, std::string filename);
