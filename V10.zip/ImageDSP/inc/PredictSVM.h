#pragma once
#include <QImage>
#include "svm.h"
#include "DataBase.h"
#include "BoW.h"
#include <string>


bool predictSVM(const ImgDataBase& dataBase, std::string BOWModelFileName, std::string SVMModelFileName);

int predictSingleImage(uchar input[], int xSize, int ySize, BagOfWordsModel& bowModel, svm_model* svmModel);
