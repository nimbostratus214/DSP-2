#include "FeatureDetection.h"
#include "ColorSpaces.h"
#include <list>

using namespace std;

#define PI 3.14159265358979323846

vector<double> calculateFeatureVector(const uchar input[], int xSize, int ySize)
{
	vector<double> features;
	
	/* TO DO */
	
	return features;
}

